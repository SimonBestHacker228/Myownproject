create function interval_pl_date(interval, date) returns timestamp without time zone
IMMUTABLE
LANGUAGE SQL
AS $$
select $2 + $1
$$;
