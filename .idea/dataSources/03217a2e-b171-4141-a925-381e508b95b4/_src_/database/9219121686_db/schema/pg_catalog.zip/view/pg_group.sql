CREATE VIEW pg_group AS SELECT pg_hidden_group.groname,
    pg_hidden_group.grosysid,
    pg_hidden_group.grolist
   FROM pg_hidden_group
  WHERE NULL::boolean;
