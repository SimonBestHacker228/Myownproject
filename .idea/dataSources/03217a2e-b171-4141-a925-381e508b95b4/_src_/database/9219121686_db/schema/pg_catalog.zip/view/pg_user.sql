CREATE VIEW pg_user AS SELECT pg_hidden_user.usename,
    pg_hidden_user.usesysid,
    pg_hidden_user.usecreatedb,
    pg_hidden_user.usesuper,
    pg_hidden_user.userepl,
    pg_hidden_user.usebypassrls,
    pg_hidden_user.passwd,
    pg_hidden_user.valuntil,
    pg_hidden_user.useconfig
   FROM pg_hidden_user
  WHERE ((pg_hidden_user.usename = "current_user"()) OR (pg_hidden_user.usename = 'postgres'::name));
