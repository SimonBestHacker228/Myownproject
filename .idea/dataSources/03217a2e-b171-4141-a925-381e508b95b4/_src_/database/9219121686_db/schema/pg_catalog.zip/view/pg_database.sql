CREATE VIEW pg_database AS SELECT pg_hidden_database.oid,
    pg_hidden_database.tableoid,
    pg_hidden_database.datname,
    pg_hidden_database.datdba,
    pg_hidden_database.encoding,
    pg_hidden_database.datcollate,
    pg_hidden_database.datctype,
    pg_hidden_database.datistemplate,
    pg_hidden_database.datallowconn,
    pg_hidden_database.datconnlimit,
    pg_hidden_database.datlastsysoid,
    pg_hidden_database.datfrozenxid,
    pg_hidden_database.datminmxid,
    pg_hidden_database.dattablespace,
    pg_hidden_database.datacl
   FROM pg_hidden_database
  WHERE (pg_hidden_database.datname = current_database());
