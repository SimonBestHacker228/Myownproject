CREATE VIEW pg_auth_members AS SELECT pg_hidden_auth_members.roleid,
    pg_hidden_auth_members.member,
    pg_hidden_auth_members.grantor,
    pg_hidden_auth_members.admin_option
   FROM pg_hidden_auth_members
  WHERE NULL::boolean;
