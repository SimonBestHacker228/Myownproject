CREATE VIEW pg_stat_database_conflicts AS SELECT pg_hidden_stat_database_conflicts.datid,
    pg_hidden_stat_database_conflicts.datname,
    pg_hidden_stat_database_conflicts.confl_tablespace,
    pg_hidden_stat_database_conflicts.confl_lock,
    pg_hidden_stat_database_conflicts.confl_snapshot,
    pg_hidden_stat_database_conflicts.confl_bufferpin,
    pg_hidden_stat_database_conflicts.confl_deadlock
   FROM pg_hidden_stat_database_conflicts
  WHERE (pg_hidden_stat_database_conflicts.datname = current_database());
