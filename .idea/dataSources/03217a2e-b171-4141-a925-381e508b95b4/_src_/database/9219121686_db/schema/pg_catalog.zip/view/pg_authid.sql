CREATE VIEW pg_authid AS SELECT pg_hidden_authid.oid,
    pg_hidden_authid.rolname,
    pg_hidden_authid.rolsuper,
    pg_hidden_authid.rolinherit,
    pg_hidden_authid.rolcreaterole,
    pg_hidden_authid.rolcreatedb,
    pg_hidden_authid.rolcanlogin,
    pg_hidden_authid.rolreplication,
    pg_hidden_authid.rolbypassrls,
    pg_hidden_authid.rolconnlimit,
    '********'::text AS rolpassword,
    pg_hidden_authid.rolvaliduntil
   FROM pg_hidden_authid
  WHERE ((pg_hidden_authid.rolname = "current_user"()) OR (pg_hidden_authid.rolname = 'postgres'::name));
