CREATE VIEW pg_roles AS SELECT pg_hidden_roles.rolname,
    pg_hidden_roles.rolsuper,
    pg_hidden_roles.rolinherit,
    pg_hidden_roles.rolcreaterole,
    pg_hidden_roles.rolcreatedb,
    pg_hidden_roles.rolcanlogin,
    pg_hidden_roles.rolreplication,
    pg_hidden_roles.rolconnlimit,
    pg_hidden_roles.rolpassword,
    pg_hidden_roles.rolvaliduntil,
    pg_hidden_roles.rolbypassrls,
    pg_hidden_roles.rolconfig,
    pg_hidden_roles.oid
   FROM pg_hidden_roles
  WHERE ((pg_hidden_roles.rolname = "current_user"()) OR (pg_hidden_roles.rolname = 'postgres'::name));
