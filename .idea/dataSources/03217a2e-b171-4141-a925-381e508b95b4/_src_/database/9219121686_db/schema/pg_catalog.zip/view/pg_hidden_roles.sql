CREATE VIEW pg_hidden_roles AS SELECT pg_hidden_authid.rolname,
    pg_hidden_authid.rolsuper,
    pg_hidden_authid.rolinherit,
    pg_hidden_authid.rolcreaterole,
    pg_hidden_authid.rolcreatedb,
    pg_hidden_authid.rolcanlogin,
    pg_hidden_authid.rolreplication,
    pg_hidden_authid.rolconnlimit,
    '********'::text AS rolpassword,
    pg_hidden_authid.rolvaliduntil,
    pg_hidden_authid.rolbypassrls,
    s.setconfig AS rolconfig,
    pg_hidden_authid.oid
   FROM (pg_hidden_authid
     LEFT JOIN pg_db_role_setting s ON (((pg_hidden_authid.oid = s.setrole) AND (s.setdatabase = (0)::oid))));
