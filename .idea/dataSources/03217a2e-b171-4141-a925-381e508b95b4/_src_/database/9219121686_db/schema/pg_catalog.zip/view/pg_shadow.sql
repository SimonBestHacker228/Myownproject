CREATE VIEW pg_shadow AS SELECT pg_hidden_authid.rolname AS usename,
    pg_hidden_authid.oid AS usesysid,
    pg_hidden_authid.rolcreatedb AS usecreatedb,
    pg_hidden_authid.rolsuper AS usesuper,
    pg_hidden_authid.rolreplication AS userepl,
    pg_hidden_authid.rolbypassrls AS usebypassrls,
    pg_hidden_authid.rolpassword AS passwd,
    (pg_hidden_authid.rolvaliduntil)::abstime AS valuntil,
    s.setconfig AS useconfig
   FROM (pg_hidden_authid
     LEFT JOIN pg_db_role_setting s ON (((pg_hidden_authid.oid = s.setrole) AND (s.setdatabase = (0)::oid))))
  WHERE pg_hidden_authid.rolcanlogin;
